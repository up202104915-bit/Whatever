from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Tuple

import numpy as np


@dataclass
class CEMConfig:
    horizon: int = 20
    population_size: int = 256
    elite_fraction: float = 0.1
    iterations: int = 5
    smoothing: float = 0.7
    gamma: float = 0.99
    min_std: float = 0.2
    seed: int = 11


class CEMPlanner:
    """Cross-Entropy Method planner for model-based action sequence optimization."""

    def __init__(
        self,
        action_low: np.ndarray,
        action_high: np.ndarray,
        config: CEMConfig | None = None,
    ) -> None:
        self.action_low = np.asarray(action_low, dtype=np.float32)
        self.action_high = np.asarray(action_high, dtype=np.float32)
        if self.action_low.shape != self.action_high.shape:
            raise ValueError("action_low and action_high must have the same shape.")
        self.action_dim = self.action_low.shape[0]
        self.config = config or CEMConfig()
        self.rng = np.random.default_rng(self.config.seed)

    def _evaluate_sequence(
        self,
        initial_temperature: float,
        action_sequence: np.ndarray,
        environment_forecast: np.ndarray,
        dynamics_model,
        reward_fn: Callable[[float, np.ndarray, np.ndarray, float], float],
    ) -> float:
        zone_temperature = float(initial_temperature)
        score = 0.0
        for t in range(self.config.horizon):
            features = np.concatenate(
                [environment_forecast[t], np.array([zone_temperature]), action_sequence[t]]
            ).astype(np.float32)
            temp_mean, temp_std = dynamics_model.predict(features)
            next_zone_temperature = float(temp_mean[0])
            uncertainty = float(temp_std[0])
            step_reward = reward_fn(
                next_zone_temperature, action_sequence[t], environment_forecast[t], uncertainty
            )
            score += (self.config.gamma ** t) * step_reward
            zone_temperature = next_zone_temperature
        return float(score)

    def _evaluate_population(
        self,
        initial_temperature: float,
        action_population: np.ndarray,
        environment_forecast: np.ndarray,
        dynamics_model,
        reward_fn: Callable[[float, np.ndarray, np.ndarray, float], float],
    ) -> np.ndarray:
        scores = np.zeros(action_population.shape[0], dtype=np.float32)
        for idx in range(action_population.shape[0]):
            scores[idx] = self._evaluate_sequence(
                initial_temperature=initial_temperature,
                action_sequence=action_population[idx],
                environment_forecast=environment_forecast,
                dynamics_model=dynamics_model,
                reward_fn=reward_fn,
            )
        return scores

    def plan(
        self,
        initial_temperature: float,
        environment_forecast: np.ndarray,
        dynamics_model,
        reward_fn: Callable[[float, np.ndarray, np.ndarray, float], float],
    ) -> Tuple[np.ndarray, float]:
        if environment_forecast.shape[0] < self.config.horizon:
            raise ValueError("environment_forecast does not cover planning horizon.")

        mean = np.tile((self.action_low + self.action_high) / 2.0, (self.config.horizon, 1))
        std = np.tile((self.action_high - self.action_low) / 2.0, (self.config.horizon, 1))
        best_sequence = mean.copy()
        best_score = -np.inf

        elite_count = max(1, int(self.config.population_size * self.config.elite_fraction))
        for _ in range(self.config.iterations):
            sampled_actions = self.rng.normal(
                loc=mean,
                scale=std,
                size=(self.config.population_size, self.config.horizon, self.action_dim),
            ).astype(np.float32)
            sampled_actions = np.clip(sampled_actions, self.action_low, self.action_high)

            scores = self._evaluate_population(
                initial_temperature=initial_temperature,
                action_population=sampled_actions,
                environment_forecast=environment_forecast,
                dynamics_model=dynamics_model,
                reward_fn=reward_fn,
            )

            elite_indices = np.argpartition(scores, -elite_count)[-elite_count:]
            elites = sampled_actions[elite_indices]
            elite_scores = scores[elite_indices]

            elite_mean = np.mean(elites, axis=0)
            elite_std = np.maximum(np.std(elites, axis=0), self.config.min_std)

            mean = self.config.smoothing * elite_mean + (1.0 - self.config.smoothing) * mean
            std = self.config.smoothing * elite_std + (1.0 - self.config.smoothing) * std

            local_best_idx = int(np.argmax(elite_scores))
            if float(elite_scores[local_best_idx]) > best_score:
                best_score = float(elite_scores[local_best_idx])
                best_sequence = elites[local_best_idx].copy()

        return best_sequence[0], best_score
