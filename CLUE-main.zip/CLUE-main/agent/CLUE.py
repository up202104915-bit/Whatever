import os
from datetime import datetime
from pathlib import Path

import gymnasium as gym
import numpy as np
import pandas as pd
import sinergym

import data.data_manager as data_manager

try:
    from agent.cem_planner import CEMConfig, CEMPlanner
    from agent.ensemble_dynamics import EnsembleDynamics, EnsembleTrainingConfig
except ImportError:
    from cem_planner import CEMConfig, CEMPlanner
    from ensemble_dynamics import EnsembleDynamics, EnsembleTrainingConfig


ACTION_MAPPING = {
    0: (15, 30),
    1: (16, 29),
    2: (17, 28),
    3: (18, 27),
    4: (19, 26),
    5: (20, 25),
    6: (21, 24),
    7: (22, 23),
    8: (22, 22),
    9: (21, 21),
}


def nearest_discrete_action(action: np.ndarray, mapping: dict) -> int:
    action = np.asarray(action, dtype=np.float32)
    best_key = 0
    best_distance = np.inf
    for key, pair in mapping.items():
        candidate = np.asarray(pair, dtype=np.float32)
        distance = np.linalg.norm(candidate - action)
        if distance < best_distance:
            best_distance = distance
            best_key = key
    return best_key


def flexibility_reward(
    next_zone_temperature: float,
    action: np.ndarray,
    forecast_row: np.ndarray,
    uncertainty: float,
    winter: bool,
    uncertainty_weight: float,
) -> float:
    people_count = float(forecast_row[4])
    heating_setpoint = float(action[0])
    cooling_setpoint = float(action[1])

    if winter:
        comfort_low, comfort_high = 20.0, 23.5
    else:
        comfort_low, comfort_high = 23.0, 26.0

    comfort_penalty = 0.0
    if people_count > 0:
        if next_zone_temperature < comfort_low:
            comfort_penalty = comfort_low - next_zone_temperature
        elif next_zone_temperature > comfort_high:
            comfort_penalty = next_zone_temperature - comfort_high

    heating_load = max(0.0, heating_setpoint - next_zone_temperature)
    cooling_load = max(0.0, next_zone_temperature - cooling_setpoint)
    estimated_hvac_effort = heating_load + cooling_load

    # Flexibility proxy: reward setpoint relaxation away from strict baseline.
    relaxed_heating = max(0.0, 21.0 - heating_setpoint)
    relaxed_cooling = max(0.0, cooling_setpoint - 21.0)
    flexibility_bonus = relaxed_heating + relaxed_cooling
    if people_count > 0:
        flexibility_bonus *= 0.2
    else:
        flexibility_bonus *= 1.0

    reward = (
        1.2 * flexibility_bonus
        - 0.3 * estimated_hvac_effort
        - 2.5 * comfort_penalty
        - uncertainty_weight * uncertainty
    )
    return float(reward)


def build_or_load_ensemble(
    x_data: np.ndarray,
    y_data: np.ndarray,
    ensemble_path: str | None,
    config: EnsembleTrainingConfig,
) -> EnsembleDynamics:
    if ensemble_path and os.path.isdir(ensemble_path):
        metadata_path = os.path.join(ensemble_path, "metadata.json")
        if os.path.exists(metadata_path):
            return EnsembleDynamics.load(ensemble_path)

    model = EnsembleDynamics(input_dim=x_data.shape[1], config=config)
    model.fit(x_data, y_data)
    if ensemble_path:
        model.save(ensemble_path)
    return model


def choose_action(
    state: float,
    horizon: int,
    environment_forecast: pd.DataFrame,
    curr_step: int,
    dynamics_model: EnsembleDynamics,
    planner: CEMPlanner,
    winter: bool,
    uncertainty_weight: float,
) -> np.ndarray:
    forecast_slice = environment_forecast.iloc[curr_step : curr_step + horizon]
    if len(forecast_slice) < horizon:
        if len(forecast_slice) == 0:
            forecast_slice = environment_forecast.iloc[-horizon:]
        while len(forecast_slice) < horizon:
            forecast_slice = pd.concat(
                [forecast_slice, forecast_slice.iloc[[-1]]], ignore_index=True
            )
    forecast_values = forecast_slice.to_numpy(dtype=np.float32)

    def reward_fn(next_zone_temp, action, forecast_row, uncertainty):
        return flexibility_reward(
            next_zone_temperature=next_zone_temp,
            action=action,
            forecast_row=forecast_row,
            uncertainty=uncertainty,
            winter=winter,
            uncertainty_weight=uncertainty_weight,
        )

    action, _ = planner.plan(
        initial_temperature=float(state),
        environment_forecast=forecast_values,
        dynamics_model=dynamics_model,
        reward_fn=reward_fn,
    )
    return action


def run_experiment(
    data_set_size,
    city,
    n_samples,
    horizon,
    path,
    epsilon,
    log=True,
    monitor_path=None,
    overhead_path=None,
    winter=True,
):
    del n_samples
    del log

    if winter:
        extra_params = {"timesteps_per_hour": 4, "runperiod": (1, 1, 1997, 31, 1, 1997)}
        env_forecast = data_manager.get_environment_forecast(city, "winter")
    else:
        extra_params = {"timesteps_per_hour": 4, "runperiod": (1, 7, 1997, 31, 7, 1997)}
        env_forecast = data_manager.get_environment_forecast(city, "summer")

    if city == "pittsburgh":
        env = gym.make("Eplus-demo-v1", config_params=extra_params, action_mapping=ACTION_MAPPING)
    elif city == "tucson":
        env = gym.make(
            "Eplus-5Zone-hot-discrete-v1", config_params=extra_params, action_mapping=ACTION_MAPPING
        )
    elif city == "new_york":
        env = gym.make(
            "Eplus-5Zone-mixed-discrete-v1",
            config_params=extra_params,
            action_mapping=ACTION_MAPPING,
        )
    else:
        raise ValueError(f"Unsupported city: {city}")

    if winter:
        x_data, y_data = data_manager.data_tree[city]["winter"]
    else:
        x_data, y_data = data_manager.data_tree[city]["summer"]

    x_data = x_data[: data_set_size * 96].to_numpy(dtype=np.float32)
    y_data = y_data[: data_set_size * 96].to_numpy(dtype=np.float32).reshape(-1)

    if path:
        raw_path = Path(path)
        ensemble_path = (
            str(raw_path.with_suffix("")) + "_ensemble" if raw_path.suffix else str(raw_path)
        )
    else:
        season = "winter" if winter else "summer"
        ensemble_path = f"./results/ensemble_models/{city}_{season}"

    ensemble_config = EnsembleTrainingConfig(
        ensemble_size=5,
        hidden_dim=64,
        epochs=80,
        batch_size=256,
        lr=1e-3,
        weight_decay=1e-5,
        bootstrap=True,
        seed=7,
    )
    dynamics_model = build_or_load_ensemble(
        x_data=x_data,
        y_data=y_data,
        ensemble_path=ensemble_path,
        config=ensemble_config,
    )

    planner = CEMPlanner(
        action_low=np.array([15.0, 21.0], dtype=np.float32),
        action_high=np.array([22.0, 30.0], dtype=np.float32),
        config=CEMConfig(
            horizon=horizon,
            population_size=256,
            elite_fraction=0.1,
            iterations=6,
            smoothing=0.7,
            gamma=0.99,
            min_std=0.2,
            seed=11,
        ),
    )

    obs, info = env.reset()
    del info
    terminated = False
    time_overhead = []
    current_step = 0

    monitor = pd.DataFrame(
        columns=[
            "year",
            "month",
            "day",
            "hour",
            "Site Outdoor Air Drybulb Temperature(Environment)",
            "Site Outdoor Air Relative Humidity(Environment)",
            "Site Wind Speed(Environment)",
            "Site Wind Direction(Environment)",
            "Site Diffuse Solar Radiation Rate per Area(Environment)",
            "Site Direct Solar Radiation Rate per Area(Environment)",
            "Zone Thermostat Heating Setpoint Temperature(SPACE1-1)",
            "Zone Thermostat Cooling Setpoint Temperature(SPACE1-1)",
            "Zone Air Temperature(SPACE1-1)",
            "Zone Air Relative Humidity(SPACE1-1)",
            "Zone People Occupant Count(SPACE1-1)",
            "People Air Temperature(SPACE1-1 PEOPLE 1)",
            "Facility Total HVAC Electricity Demand Rate(Whole Building)",
        ]
    )

    while not terminated:
        t0 = datetime.now()
        if current_step == 0:
            zone_temperature = obs.get("Zone Air Temperature(SPACE1-1)", 21.0)
        else:
            zone_temperature = obs["Zone Air Temperature(SPACE1-1)"]

        continuous_action = choose_action(
            state=zone_temperature,
            horizon=horizon,
            environment_forecast=env_forecast,
            curr_step=current_step,
            dynamics_model=dynamics_model,
            planner=planner,
            winter=winter,
            uncertainty_weight=float(epsilon),
        )
        discrete_action = nearest_discrete_action(continuous_action, ACTION_MAPPING)

        t1 = datetime.now()
        time_overhead.append(t1 - t0)
        obs, reward, terminated, truncated, info = env.step(discrete_action)
        del reward
        del truncated
        del info

        monitor = pd.concat([monitor, pd.DataFrame(obs, index=[current_step])])
        current_step += 1
        if current_step % 100 == 0 and monitor_path:
            print(current_step)
            monitor.to_csv(monitor_path)

    time_overhead = [int(t.total_seconds() * 1000) for t in time_overhead]
    if overhead_path:
        time_overhead_df = pd.DataFrame(time_overhead, columns=["time_overhead"])
        time_overhead_df.to_csv(overhead_path)
    if monitor_path:
        monitor.to_csv(monitor_path)
    env.close()


if __name__ == "__main__":
    days = 7
    eps = 0.3
    city = "pittsburgh"
    run_experiment(
        days,
        city,
        n_samples=1000,
        horizon=20,
        path=f"./results/ensemble_models/{city}_winter",
        monitor_path=f"{city}_ensemble_cem_winter_{days}_{eps}_monitor.csv",
        overhead_path=f"{city}_ensemble_cem_winter_{days}_{eps}_overhead.csv",
        epsilon=eps,
        winter=True,
    )
