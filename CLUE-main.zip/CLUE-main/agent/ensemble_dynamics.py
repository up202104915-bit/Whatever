from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Tuple

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset


class DynamicsMLP(nn.Module):
    """Lightweight one-step dynamics model used in the ensemble."""

    def __init__(self, input_dim: int, hidden_dim: int) -> None:
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.network(x)


@dataclass
class EnsembleTrainingConfig:
    ensemble_size: int = 5
    hidden_dim: int = 64
    epochs: int = 80
    batch_size: int = 256
    lr: float = 1e-3
    weight_decay: float = 1e-5
    bootstrap: bool = True
    seed: int = 7


class EnsembleDynamics:
    """Bootstrapped ensemble for epistemic uncertainty estimation."""

    def __init__(
        self,
        input_dim: int,
        config: EnsembleTrainingConfig | None = None,
        device: str | None = None,
    ) -> None:
        self.input_dim = input_dim
        self.config = config or EnsembleTrainingConfig()
        if device is None:
            device = "cuda" if torch.cuda.is_available() else "cpu"
        self.device = torch.device(device)
        self.models = [
            DynamicsMLP(input_dim, self.config.hidden_dim).to(self.device)
            for _ in range(self.config.ensemble_size)
        ]
        self.is_fitted = False

    def _sample_indices(self, n_samples: int, member_idx: int) -> np.ndarray:
        if not self.config.bootstrap:
            return np.arange(n_samples)
        rng = np.random.default_rng(self.config.seed + member_idx)
        return rng.integers(0, n_samples, size=n_samples)

    def fit(self, x: np.ndarray, y: np.ndarray) -> None:
        x = np.asarray(x, dtype=np.float32)
        y = np.asarray(y, dtype=np.float32).reshape(-1)
        if x.ndim != 2:
            raise ValueError("x must be 2D [n_samples, n_features].")
        if x.shape[1] != self.input_dim:
            raise ValueError(
                f"input dimension mismatch: expected {self.input_dim}, got {x.shape[1]}"
            )

        n_samples = x.shape[0]
        for member_idx, model in enumerate(self.models):
            member_indices = self._sample_indices(n_samples, member_idx)
            x_member = torch.from_numpy(x[member_indices])
            y_member = torch.from_numpy(y[member_indices]).unsqueeze(-1)
            dataset = TensorDataset(x_member, y_member)
            loader = DataLoader(
                dataset,
                batch_size=min(self.config.batch_size, len(dataset)),
                shuffle=True,
            )

            optimizer = torch.optim.Adam(
                model.parameters(),
                lr=self.config.lr,
                weight_decay=self.config.weight_decay,
            )
            criterion = nn.MSELoss()
            model.train()

            for _ in range(self.config.epochs):
                for x_batch, y_batch in loader:
                    x_batch = x_batch.to(self.device)
                    y_batch = y_batch.to(self.device)
                    optimizer.zero_grad()
                    pred = model(x_batch)
                    loss = criterion(pred, y_batch)
                    loss.backward()
                    optimizer.step()

        self.is_fitted = True

    def predict(self, x: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        if not self.is_fitted:
            raise RuntimeError("EnsembleDynamics must be fitted before predict().")

        x = np.asarray(x, dtype=np.float32)
        if x.ndim == 1:
            x = x.reshape(1, -1)
        if x.shape[1] != self.input_dim:
            raise ValueError(
                f"input dimension mismatch: expected {self.input_dim}, got {x.shape[1]}"
            )

        x_tensor = torch.from_numpy(x).to(self.device)
        predictions = []
        for model in self.models:
            model.eval()
            with torch.no_grad():
                pred = model(x_tensor).squeeze(-1).cpu().numpy()
                predictions.append(pred)

        stacked_predictions = np.stack(predictions, axis=0)
        mean_prediction = stacked_predictions.mean(axis=0)
        std_prediction = stacked_predictions.std(axis=0) + 1e-6
        return mean_prediction, std_prediction

    def save(self, save_dir: str) -> None:
        directory = Path(save_dir)
        directory.mkdir(parents=True, exist_ok=True)
        metadata = {
            "input_dim": self.input_dim,
            "config": asdict(self.config),
        }
        (directory / "metadata.json").write_text(json.dumps(metadata), encoding="utf-8")
        for idx, model in enumerate(self.models):
            torch.save(model.state_dict(), directory / f"member_{idx}.pt")

    @classmethod
    def load(cls, save_dir: str, device: str | None = None) -> "EnsembleDynamics":
        directory = Path(save_dir)
        metadata_path = directory / "metadata.json"
        if not metadata_path.exists():
            raise FileNotFoundError(f"Missing ensemble metadata: {metadata_path}")

        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        config = EnsembleTrainingConfig(**metadata["config"])
        model = cls(metadata["input_dim"], config=config, device=device)
        for idx, member in enumerate(model.models):
            weights_path = directory / f"member_{idx}.pt"
            state_dict = torch.load(weights_path, map_location=model.device)
            member.load_state_dict(state_dict)
        model.is_fitted = True
        return model
